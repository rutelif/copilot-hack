#!/usr/bin/env python3
"""Convert the supplied sticker into SVG paths, render PNG, and create a ZIP.

Requires Python 3.10+, the packages in requirements.txt, and Inkscape on PATH.
The source image is included so the artwork can be reproduced offline.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile

from PIL import Image, ImageFilter
import vtracer


def generate(source: Path, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    source_copy = output / "original.png"
    if source.resolve() != source_copy.resolve():
        shutil.copy2(source, source_copy)

    with Image.open(source_copy) as opened:
        source_image = opened.convert("RGB")
    width, height = source_image.size
    svg = output / "sticker.svg"

    # Reduce photographic grain without changing the layout or adding new text.
    # The resulting SVG contains actual vector paths, not an embedded bitmap.
    with tempfile.TemporaryDirectory(prefix="guinness-sticker-") as temp:
        prepared = Path(temp) / "palette.png"
        source_image.filter(ImageFilter.MedianFilter(3)).quantize(
            colors=24, method=Image.Quantize.MEDIANCUT
        ).convert("RGB").save(prepared)
        vtracer.convert_image_to_svg_py(
            str(prepared), str(svg),
            colormode="color", hierarchical="stacked", mode="spline",
            filter_speckle=4, color_precision=6, layer_difference=8,
            corner_threshold=60, length_threshold=3.5, max_iterations=10,
            splice_threshold=45, path_precision=3,
        )

    namespace = "http://www.w3.org/2000/svg"
    ET.register_namespace("", namespace)
    tree = ET.parse(svg)
    root = tree.getroot()
    root.set("viewBox", f"0 0 {width} {height}")
    root.set("role", "img")
    title = ET.Element(f"{{{namespace}}}title")
    title.text = "BOTTOMLESS GUINNESS — green and yellow sticker"
    root.insert(0, title)
    if any(item.tag.endswith("image") for item in root.iter()):
        raise RuntimeError("SVG must contain vectors, not embedded raster images")
    tree.write(svg, encoding="utf-8", xml_declaration=True)

    # Render from the generated SVG so the PNG verifies the vector output.
    inkscape = shutil.which("inkscape")
    if not inkscape:
        raise RuntimeError("Install Inkscape and put it on PATH to render PNG")
    png = output / "sticker.png"
    subprocess.run([
        inkscape, str(svg), "--export-type=png",
        f"--export-filename={png}", f"--export-width={width * 2}",
    ], check=True)
    with Image.open(png) as rendered:
        rendered.load()
        if rendered.size != (width * 2, height * 2):
            raise RuntimeError(f"Unexpected PNG size: {rendered.size}")
        rendered.save(png, dpi=(300, 300))

    hashes = {
        filename: hashlib.sha256((output / filename).read_bytes()).hexdigest()
        for filename in ("original.png", "sticker.svg", "sticker.png")
    }
    (output / "SHA256.json").write_text(
        json.dumps(hashes, indent=2) + "\n", encoding="utf-8"
    )
    for name in ("create_sticker.py", "requirements.txt", "README.txt"):
        supplied = Path(__file__).resolve().parent / name
        destination = output / name
        if supplied.resolve() != destination.resolve():
            shutil.copy2(supplied, destination)

    archive = output.parent / "guinness-sticker.zip"
    names = [
        "sticker.svg", "sticker.png", "original.png", "create_sticker.py",
        "requirements.txt", "README.txt", "SHA256.json",
    ]
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zipped:
        for name in names:
            zipped.write(output / name, arcname=f"guinness-sticker/{name}")
    with zipfile.ZipFile(archive) as zipped:
        if zipped.testzip() is not None:
            raise RuntimeError("ZIP integrity check failed")
        if len(zipped.namelist()) != len(names):
            raise RuntimeError("Incomplete ZIP")
    print(f"Created: {archive}")
    print(f"SVG: {sum(1 for p in root.iter() if p.tag.endswith('path'))} vector paths")
    print(f"PNG: {width * 2} x {height * 2}, 300 DPI metadata")
    print("ZIP integrity: passed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path,
                        default=Path(__file__).resolve().parent / "original.png")
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parent / "output")
    args = parser.parse_args()
    generate(args.source, args.output)
