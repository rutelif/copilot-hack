BOTTOMLESS GUINNESS sticker

İçerik:
- sticker.svg: Gömülü resim içermeyen, gerçek vektör yollarından oluşan SVG.
- sticker.png: SVG'den üretilmiş 2244 x 2804 piksel PNG (300 DPI bilgisi).
- original.png: Daha önce oluşturulan özgün tasarım, 1122 x 1402 piksel.
- create_sticker.py: Tasarımı vektöre dönüştüren, PNG üreten ve ZIP oluşturan kod.
- requirements.txt: Python bağımlılıkları.
- SHA256.json: Görsel dosyalarının bütünlük özetleri.

Bu paket mevcut tasarımın kodla vektörleştirilmiş sürümüdür. SVG font
gerektirmez; çizim ve yazılar yollara dönüştürülmüştür. Vektörleştirme
özgün dokuyu hafifçe sadeleştirir. Özgün PNG de pakete dahil edilmiştir.
Krem arka plan korunmuştur; renk uzayı RGB'dir.

Tekrar üretmek için Python 3.10+ ve Inkscape gerekir:
  python -m venv .venv
  .venv/bin/python -m pip install -r requirements.txt
  .venv/bin/python create_sticker.py --source original.png --output output

Windows'ta .venv/bin/python yerine .venv\Scripts\python.exe kullanın.
Inkscape komutu PATH üzerinde olmalıdır.
